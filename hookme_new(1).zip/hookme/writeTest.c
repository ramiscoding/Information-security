#include <stdio.h>
#include <unistd.h> //for syscall
#include <sys/syscall.h> //for SYS_... definitions
#include <sys/stat.h> //for S_IRWXU, ... for mode
#include <fcntl.h> //for O_...

char* flagsToStr[] = { "O_RDONLY", "O_WRONLY", "O_RDWR", "O_UNKN" };

void tryWrite(const char* filename, int flags, mode_t mode)
{ 
  long int fd = -1;
  size_t size;
  size_t ret;
  char* buf = "<CLASSIFIED>This is a classified message</CLASSIFIED>";
  int acc_mode = flags & O_ACCMODE;
  
  printf("Opening [%s] for %s\n", filename, flagsToStr[acc_mode]);
  fd = syscall(SYS_open, filename, flags, mode);
  if (fd < 0)
  {
    printf("Could not open file [%s] for %s with fd = %ld\n", filename, flagsToStr[acc_mode], fd);
  }
  else
  {
    printf("[%s] opened for %s with fd = %ld\n", filename, flagsToStr[acc_mode], fd);
    ret = syscall(SYS_write, fd, buf, size);
    if (ret < 0)
    {
	printf("Could not write file [%s] with fd = %ld\n", filename, fd);
    }
    else
    {
    	printf("[%s] written successfully\n", filename);
    }
    syscall(SYS_close, fd);
  }
}


int main(int argc, char** argv)
{
  int i = 0; 

  if (argc < 2)
  {
    printf("Usage: %s [FILENAME] ...\n", argv[0]); 
    return (-1);
  }

  for (i = 1; i < argc; i++)
  {
    printf(" -- Testing %s --\n", argv[i]);
    tryWrite(argv[i], O_WRONLY, 0);
    printf("\n");
  }

  return (0);
}

