#include <linux/module.h>	/* Needed by all modules */
#include <linux/kernel.h>	/* Needed for KERN_INFO */
#include <linux/version.h>
#include <linux/syscalls.h>
#include <linux/security.h>
#include <linux/sched.h>
#include <linux/mm.h>
#include <linux/fs.h>
#include <linux/dcache.h>

//include for the read/write semaphore
#include <linux/rwsem.h>

//needed for set_memory_rw
#include <asm/cacheflush.h>

#include "offsets.h"

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,0,0)
#error "NOT YET SUPPORTED"
#elif LINUX_VERSION_CODE >= KERNEL_VERSION(4,0,0)
#define _LINUX_VERSION_4
#elif LINUX_VERSION_CODE >= KERNEL_VERSION(3,0,0)
#define _LINUX_VERSION_3
#else
#error "KERNEL 2 is not yet supported"
#endif


//These two definitions and the one for set_addr_rw and ro are from
// http://stackoverflow.com/questions/2103315/linux-kernel-system-call-hooking-example
#define GPF_DISABLE() write_cr0(read_cr0() & (~0x10000))
#define GPF_ENABLE() write_cr0(read_cr0() | 0x10000)

#ifdef _LINUX_VERSION_4
//#define INVALID_UID (-1) //Linux 4.0 uses a struct kuid_t wrapper for uid_t and INVALID_UID is now the struct for (-1) -- see include/linux/uidgid.h
#define MY_INVALID_UID (INVALID_UID.val)
#define MY_CURRENT_UID (current_uid().val)
#define MY_CURRENT_EUID (current_euid().val)
//current_uid returns the kuid -- see include/linux/cred.h

//it appears that putname and getname are no longer exported, so will have to use the configure kallsyms trick
typedef void (*fs_putname_func)(struct filename*);
fs_putname_func sym_putname = (fs_putname_func)FS_PUTNAME_ADDR;

typedef struct filename* (*fs_getname_func)(const char __user*);
fs_getname_func sym_getname= (fs_getname_func)FS_GETNAME_ADDR;
#elif defined(_LINUX_VERSION_3)
#define MY_INVALID_UID (-1)
#define MY_CURRENT_UID current_uid()
#define MY_CURRENT_EUID current_euid()

#endif

//task_struct is defined in include/linux/sched.h

//Here is a function to get the filename given a fd -- from
// http://stackoverflow.com/questions/8250078/how-can-i-get-a-filename-from-a-file-descriptor-inside-a-kernel-module
#include <linux/fdtable.h>
//char* getFilenameFromFD(unsigned int fd, char** pPage)
char* getFilenameFromFD(unsigned int fd)
{
  char *tmp;
  char *pathname;
  struct file *file;
  struct path path;

  if (current->files == NULL) 
  {
    return (NULL);
  }

  spin_lock(&(current->files->file_lock));
  file = fcheck_files(current->files, fd);
  if (file == NULL) 
  {
    spin_unlock(&(current->files->file_lock));
    return NULL;
  }

  path = file->f_path;
  path_get(&file->f_path);
  spin_unlock(&(current->files->file_lock));

  tmp = (char *)__get_free_page(GFP_TEMPORARY);

  if (tmp == NULL) 
  {
    path_put(&path);
    return (NULL);
  }

  pathname = d_path(&path, tmp, PAGE_SIZE);
  path_put(&path);

  if (IS_ERR(pathname)) 
  {
    free_page((unsigned long)tmp);
    return (NULL);
  }

  /*if (pPage != NULL)
  {
    *pPage = tmp;
  }*/

  return (pathname);
 
  //dont forget to free the page afterwards
  //free_page((unsigned long)tmp);
}

// Function to reverse a null terminated string

char *strrev(char *str)
{
      char *p1, *p2;

      if (! str || ! *str)
            return str;
      for (p1 = str, p2 = str + strlen(str) - 1; p2 > p1; ++p1, --p2)
      {
            *p1 ^= *p2;
            *p2 ^= *p1;
            *p1 ^= *p2;
      }
      return str;
}




//seed@ubuntu:~/Downloads/hw5$ sudo grep sys_call_table /proc/kallsyms
//c1513160 R sys_call_table
static long* sys_call_table = (long*)SYS_CALL_TABLE_ADDR;

typedef asmlinkage long (* sys_open_func_ptr)(const char __user* filename, int flags, int mode);
sys_open_func_ptr sys_open_orig = NULL;

typedef asmlinkage long (* sys_read_func_ptr)(unsigned int fd, char __user* buf, size_t count);
sys_read_func_ptr sys_read_orig = NULL;

typedef asmlinkage long (* sys_write_func_ptr)(unsigned int fd, char __user* buf, size_t count);
sys_write_func_ptr sys_write_orig = NULL;

typedef asmlinkage long (* sys_close_func_ptr)(unsigned int fd);
sys_close_func_ptr sys_close_orig = NULL;

static struct rw_semaphore myrwsema; 

/** RULES **/
#define MAX_RULE_STR_LEN 128
#define MAX_RULES_IN_POLICY 20

typedef struct _rule
{
  uid_t uid;
  enum {READ_ACCESS=0, WRITE_ACCESS, READ_EXCEPT_ACCESS, WRITE_ONLY_ACCESS} access;
  char filename[MAX_RULE_STR_LEN];
  char keyword[MAX_RULE_STR_LEN];  
} Rule;

char* accessToString[] = {"READ", "WRITE", "READ", "WRITE"};
char* accessToString2[] = {"", "", "EXCEPT", "ONLY"};

Rule myPolicy[MAX_RULES_IN_POLICY];

/** My hooked versions of the system calls **/
//don't forget the asmlinkage declaration. This is a particular calling convention
asmlinkage long my_sys_open(const char __user* filename, int flags, int mode)
{
  long ret = 0;

#ifdef _LINUX_VERSION_4
  //Linux 4 now uses a struct filename so getname and putname uses struct filenames -- see include/linux/fs.h
  struct filename* tmpFN = NULL;
#elif defined(_LINUX_VERSION_3)
  //Nothing to do there
#endif
  const char* tmp = NULL;
  char* tmpFilename = "BUG!!!FIXME";

  size_t i = 0;
  int allowedAccess = 0x3; //default allow - this is a bit mask
                           //first bit is read, second bit is write
  int bFirstRule = 1; //a flag to see if the current rule is the first rule fo rthe file

  //int acc_mode = ACC_MODE(flags); //note that ACC_MODE gives us "\004\002\006\006"[(x) & O_ACCMODE] meaning
                                    // O_RDONLY is now ?, O_WRONLY is O_RDWR, O_RDWR is ?
  //So, we will just use O_ACCMODE instead
  int acc_mode = flags & O_ACCMODE;

  //add in another reader to the semaphore
  down_read(&myrwsema);

  //get the filename from userspace memory
#ifdef _LINUX_VERSION_4
  tmpFN = sym_getname(filename);
  if (IS_ERR(tmpFN))
  {
    tmp = (char *)tmpFN; //ERR_PTR should be generic so we can cast it
  }
  else
  {
    tmp = tmpFN->name;
  }
#elif defined(_LINUX_VERSION_3)
  tmp = getname(filename);
#endif

  //if there wasn't an error then we continue
  if (!IS_ERR(tmp))
  {
    //printk(KERN_INFO "File [%s] is being opened with Flags [%x] and mode [%x]\n", tmp, flags, mode);
    //go through the rules and see if there is oen for this file
    for (i = 0; i < MAX_RULES_IN_POLICY; i++)
    {
      //because of the simple way I represent the rules
      // I can short circuit the search once I see 
      // an invalid UID
      if ( myPolicy[i].uid == MY_INVALID_UID )
      {
        break;
      }
    
      //check the uids first
      if ( (MY_CURRENT_UID == myPolicy[i].uid) || (MY_CURRENT_EUID == myPolicy[i].uid) )
      {
        //if the current uid or euid is specified in the rule
        // then see if the file being opened is also in the rule

        if (strcmp(filename, myPolicy[i].filename) == 0) 
        {
          printk(KERN_INFO "File [%s] is being opened with Flags [%x] and mode [%x]\n", tmp, flags, mode);
          //since the filenames are the same we now change the allowedAccess
          // to 0 (deny) - the actual rules will set the other permissions
          // we only do it if its the first rule
          if (bFirstRule)
          {
            allowedAccess = 0;
            bFirstRule = 0;
            tmpFilename = myPolicy[i].filename;
          }

          if ( (myPolicy[i].access == READ_ACCESS) || (myPolicy[i].access == READ_EXCEPT_ACCESS) )
          {
            allowedAccess |= 0x1; 
          }

          if ( (myPolicy[i].access == WRITE_ACCESS) || (myPolicy[i].access == WRITE_ONLY_ACCESS) )
          {
            allowedAccess |= 0x2; 
          }
        }
      }
    }
    //we are done with the filename so lets free the memory
#ifdef _LINUX_VERSION_4
    sym_putname(tmpFN);
    tmpFN = NULL;
    tmp = NULL;
#elif defined(_LINUX_VERSION_3)
    putname(tmp);
    tmp = NULL;
#endif
  }


  //now that we are out here - it means that allowedAccess will tell us which
  // accesses are allowed by the policy - so lets check it against the modes that we are
  // interested in
  if (acc_mode == O_RDONLY)
  {
    if (!(allowedAccess & 0x1)) //if it is not allowed
    {
      ret = -1;
      printk(KERN_INFO "The file [%s] is being opened for RDONLY [%d], but is not allowed\n", tmpFilename, acc_mode);
    }
    else 
    {
      ret = sys_open_orig(filename, flags, mode);
    }
  }
  else if (acc_mode == O_WRONLY)
  {
    if (!(allowedAccess & 0x2)) //if it is not allowed
    {
      ret = -1;
      printk(KERN_INFO "The file [%s] is being opened for WRONLY [%d], but is not allowed\n", tmpFilename, acc_mode);
    }
    else
    {
      ret = sys_open_orig(filename, flags, mode);
    }
  }
  else if (acc_mode == O_RDWR)
  {
    if (!(allowedAccess == 0x3)) //if it is not allowed
    {
      ret = -1;
      printk(KERN_INFO "The file [%s] is being opened for RDWR [%d], but is not allowed\n", tmpFilename, acc_mode);
    }
    else
    {
      ret = sys_open_orig(filename, flags, mode);
    }
  }
  else
  {
    ret = sys_open_orig(filename, flags, mode);
  }

  //release the reader lock (or one of them) right before the return
  // to limit the possibility of unloading the module
  // when there is still code to be executed
  up_read(&myrwsema);

  return (ret);
}

asmlinkage long my_sys_read(unsigned int fd, char __user* buf, size_t count)
{
  long ret = 0;
  size_t i = 0;
  size_t j = 0;
  size_t k = 0;
  int dontWriteFlag = 0;
  // Default allow policy will also be checked later

  int a = 0;
  int b = 0;
  int l = 0;

  char* myKeyword = "testfile";
  char* buf2 = "This is buffer two";
  char* buf3 = "This is buffer three";
  char* buf4 = "This is buffer four";
  int allowedAccess = 0; 
  
  //printk(KERN_INFO "File is being read in my_sys_read\n");
  down_read(&myrwsema);

  // My code starts here

  for (i = 0; i < MAX_RULES_IN_POLICY; i++)
    {
      
      if ( myPolicy[i].uid == MY_INVALID_UID )
      {
        break;
      }
    
      //check the uids first
      if ( (MY_CURRENT_UID == myPolicy[i].uid) || (MY_CURRENT_EUID == myPolicy[i].uid) )
      {
        //if the current uid or euid is specified in the rule
        // then see if the file being opened is also in the rule
	
	char* myFileName = getFilenameFromFD(fd);
	printk(KERN_INFO "File [%s] is being read\n", myFileName);
        if (strcmp(myFileName, myPolicy[i].filename) == 0) 
        {
          printk(KERN_INFO "File [%s] is being read\n", myFileName);

          if ( myPolicy[i].access == READ_ACCESS )
          {
            allowedAccess = 1; 
          }

          if ( myPolicy[i].access == READ_EXCEPT_ACCESS )
          {
            allowedAccess = 2;
	    myKeyword = myPolicy[i].keyword; 
	    printk(KERN_INFO "File is being read with keyword [%s]\n", myKeyword);
          }
        }
      }
    }
   
  if (allowedAccess == 2)
  {
	int accessLength = strlen(myKeyword);
	char* obtainedKeyword = "Sample keyword";
	ret = sys_read_orig(fd, buf, count);
	printk(KERN_INFO "Original system call called\n");
	for ( j = 0 ; j < count ; j++)
	{
		if (dontWriteFlag == 1)
		{
			if (buf[j] == '>')
			{
				int newLength = accessLength;
				for ( l = (j - 1); newLength < 0; l--)
				{
					buf4[b] = l;
					b++;
					newLength = newLength - 1;
				} 
				obtainedKeyword = strrev(buf4);
				if (strcmp(obtainedKeyword,myKeyword) == 0)
				{
					dontWriteFlag = 0;
				}
			}
			continue;
		}
		else if (buf[j] == '<')
		{
			for ( k = (j + 1); k < accessLength; k++)
			{
				buf2[a] = k;
				a++;
			} 
			if (strcmp(buf2, myKeyword) == 0)
			{
				dontWriteFlag = 1;	
			}
			else 
			{
				buf3[j] = buf[j];
			}
		}
		else 
		{
			buf3[j] = buf[j];
		}
	}
	// Set our modified buffer to original buffer
	buf = buf3;
	printk(KERN_INFO "File read with keyword successfully\n");
	up_read(&myrwsema);
  	return (ret);
  }

  
  // My code ends here

  ret = sys_read_orig(fd, buf, count);

  up_read(&myrwsema);
  return (ret);
}

asmlinkage long my_sys_write(unsigned int fd, char __user* buf, size_t count)
{
  long ret = 0;

  size_t i = 0;
  size_t j = 0;
  size_t k = 0;
  int WriteFlag = 0;
  // Default allow policy will also be checked later

  int a = 0;
  int b = 0;
  int c = 0;
  int l = 0;

  char* myKeyword = "testfile";
  char* buf2 = "This is buffer two";
  char* buf3 = "This is buffer three";
  char* buf4 = "This is buffer four";
  int allowedAccess = 0;

  down_write(&myrwsema);
  // My code starts here

  for (i = 0; i < MAX_RULES_IN_POLICY; i++)
    {
      if ( myPolicy[i].uid == MY_INVALID_UID )
      {
        break;
      }
    
      //check the uids first
      if ( (MY_CURRENT_UID == myPolicy[i].uid) || (MY_CURRENT_EUID == myPolicy[i].uid) )
      {
        //if the current uid or euid is specified in the rule
        // then see if the file being opened is also in the rule
	
	char* myFileName = getFilenameFromFD(fd);
        if (strcmp(myFileName, myPolicy[i].filename) == 0) 
        {
          printk(KERN_INFO "File [%s] is being written\n", myFileName);
          if ( myPolicy[i].access == WRITE_ACCESS )
          {
            allowedAccess = 1; 
          }

          if ( myPolicy[i].access == WRITE_ONLY_ACCESS )
          {
            allowedAccess = 2;
	    myKeyword = myPolicy[i].keyword; 
	    printk(KERN_INFO "File is being written with keyword [%s]\n", myKeyword);
          }
        }
      }
    }
   
  if (allowedAccess == 2)
  {
	//ret = sys_write_orig(fd, buf, count);
	int accessLength = strlen(myKeyword);
	char* obtainedKeyword = "Test keyword";
	for ( j = 0 ; j < count ; j++)
	{
		if (WriteFlag == 1)
		{
			if (buf[j] == '>')
			{
				int newLength = accessLength;
				for ( l = (j - 1); newLength < 0; l--)
				{
					buf4[c] = l;
					c++;
					newLength = newLength - 1;
				} 
				obtainedKeyword = strrev(buf4);
				if (strcmp(obtainedKeyword,myKeyword) == 0)
				{
					WriteFlag = 0;
				}
			}
			//continue;
			buf3[b] = j;
		        b++;
		}
		else if (buf[j] == '<')
		{
			for ( k = (j + 1); k < accessLength; k++)
			{
				buf2[a] = k;
				a++;
			} 
			if (strcmp(buf2, myKeyword) == 0)
			{
				WriteFlag = 1;	
				buf3[b] = j;
				b++;
			}
			else 
			{
				//buf3[j] = buf[j];
				continue;
			}
		}
		else 
		{
			//buf3[j] = buf[j];
			continue;
		}
	}
	// Set our modified buffer to original buffer
	//buf = buf3;
	//up_read(&myrwsema);
  	//return (ret);
	buf = buf3;
	printk(KERN_INFO "File written with keyword successfully\n");
  }

  
  
  // My code ends here



  //we want to first write the contents
  ret = sys_write_orig(fd, buf, count);

  //up_write(&myrwsema);
  return (ret);
}

/** The following functions are needed to hook the system call table **/

int set_addr_rw(unsigned long addr)
{
  unsigned int level; 
  pte_t* pte = lookup_address(addr, &level);
  if (pte == NULL)
  {
    return (-1);
  }

  pte->pte |= _PAGE_RW;

  return (0);
}

int set_addr_ro(unsigned long addr)
{
  unsigned int level; 
  pte_t* pte = lookup_address(addr, &level);
  if (pte == NULL)
  {
    return (-1);
  }

  pte->pte = pte->pte & ~_PAGE_RW;

  return (0);
}

/** Helper functions **/
void printkRules(void)
{
  size_t i = 0;
  for (i = 0; i < MAX_RULES_IN_POLICY; i++)
  {
    if (myPolicy[i].uid != MY_INVALID_UID)
    {
      printk(KERN_INFO "UID [%d] can %s file [%s] %s <%s>\n", myPolicy[i].uid, accessToString[myPolicy[i].access], myPolicy[i].filename, accessToString2[myPolicy[i].access], myPolicy[i].keyword);
    }  
  }
}

int init_module(void)
{
  size_t i = 0;

  //sys_close is exported, so we can use it to make sure we have the
  // right address for sys_call_table
  //printk(KERN_INFO "sys_close is at [%p] == [%p]?.\n", sys_call_table[__NR_close], &sys_close);
  if (sys_call_table[__NR_close] != (long)(&sys_close))
  {
    printk(KERN_INFO "Seems like we don't have the right addresses [0x%08lx] vs [%p]\n", sys_call_table[__NR_close], &sys_close);
    return (-1); 
  }

  //initialize the rules 
  for (i = 0; i < MAX_RULES_IN_POLICY; i++)
  {
    myPolicy[i].uid = MY_INVALID_UID;
    myPolicy[i].keyword[0] = '\0';
    myPolicy[i].filename[0] = '\0';
  }

  //TEST
  myPolicy[0].uid = 1000;
  myPolicy[0].access = READ_EXCEPT_ACCESS;
  strcpy(myPolicy[0].filename, "secret.txt");
  strcpy(myPolicy[0].keyword, "SECRET");

  myPolicy[1].uid = 1000;
  myPolicy[1].access = WRITE_ACCESS;
  strcpy(myPolicy[1].filename, "secret2.txt");

  myPolicy[2].uid = 2000;
  myPolicy[2].access = READ_ACCESS;
  strcpy(myPolicy[2].filename, "topsecret.txt");


  myPolicy[3].uid = 2000;
  myPolicy[3].access = WRITE_ACCESS;
  strcpy(myPolicy[3].filename, "topsecret1.txt");

  
  myPolicy[4].uid = 2000;
  myPolicy[4].access = READ_ACCESS;
  strcpy(myPolicy[4].filename, "topsecret2.txt");


  myPolicy[5].uid = 1000;
  myPolicy[5].access = READ_EXCEPT_ACCESS;
  strcpy(myPolicy[5].filename, "topsecret3.txt");
  strcpy(myPolicy[5].keyword, "TOPSECRET");


  myPolicy[6].uid = 2001;
  myPolicy[6].access = READ_ACCESS;
  strcpy(myPolicy[6].filename, "classified.txt");


  myPolicy[7].uid = 2001;
  myPolicy[7].access = READ_ACCESS;
  strcpy(myPolicy[7].filename, "classified1.txt");


  myPolicy[8].uid = 2001;
  myPolicy[8].access = WRITE_ACCESS;
  strcpy(myPolicy[8].filename, "classified2.txt");


  myPolicy[9].uid = 1000;
  myPolicy[9].access = WRITE_ONLY_ACCESS;
  strcpy(myPolicy[9].filename, "classified3.txt");
  strcpy(myPolicy[9].keyword, "CLASSIFIED");


  //initialize the rw semahore
  init_rwsem(&myrwsema);

  //make sure the table is writable
  set_addr_rw( (unsigned long)sys_call_table);
  //GPF_DISABLE();

  printk(KERN_INFO "Saving sys_open @ [0x%08lx]\n", sys_call_table[__NR_open]);
  sys_open_orig = (sys_open_func_ptr)(sys_call_table[__NR_open]);
  sys_call_table[__NR_open] = (long)&my_sys_open;

  printk(KERN_INFO "Saving sys_read @ [0x%08lx]\n", sys_call_table[__NR_read]);
  sys_read_orig = (sys_read_func_ptr)(sys_call_table[__NR_read]);
  sys_call_table[__NR_read] = (long)&my_sys_read;

  //printk(KERN_INFO "Saving sys_write @ [0x%08lx]\n", sys_call_table[__NR_write]);
  //sys_write_orig = (sys_write_func_ptr)(sys_call_table[__NR_write]);
  //sys_call_table[__NR_write] = (long)&my_sys_write;  

  set_addr_ro( (unsigned long)sys_call_table);
  //GPF_ENABLE();

  return (0);
}

void cleanup_module(void)
{
  if (sys_open_orig != NULL)
  {
    set_addr_rw( (unsigned long)sys_call_table);

    printk(KERN_INFO "Restoring sys_open\n");
    sys_call_table[__NR_open] = (long)sys_open_orig; 

    printk(KERN_INFO "Restoring sys_read\n");
    sys_call_table[__NR_read] = (long)sys_read_orig; 

    //printk(KERN_INFO "Restoring sys_write\n");
    //sys_call_table[__NR_write] = (long)sys_write_orig;

    set_addr_ro( (unsigned long)sys_call_table);
  }

  //after the system call table has been restored - we will need to wait
  printk(KERN_INFO "Checking the semaphore as a write ...\n");
  down_write(&myrwsema);
  
  printk(KERN_INFO "Have the write lock - meaning all read locks have been released\n");
  printk(KERN_INFO " So it is now safe to remove the module\n");

  printk(KERN_INFO "The final rules were: \n");
  printkRules();
}

MODULE_LICENSE("GPL");
