#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0xa683b406, "module_layout" },
	{ 0x657879ce, "__init_rwsem" },
	{ 0xe914e41e, "strcpy" },
	{ 0x268cc6a2, "sys_close" },
	{ 0x15568631, "lookup_address" },
	{ 0x61b5ade0, "down_write" },
	{ 0xd0d8621b, "strlen" },
	{ 0x4302d0eb, "free_pages" },
	{ 0xdca9fbbd, "path_put" },
	{ 0x8d7b3177, "d_path" },
	{ 0x93fca811, "__get_free_pages" },
	{ 0x76ebea8, "pv_lock_ops" },
	{ 0x2251ff67, "path_get" },
	{ 0x67f7403e, "_raw_spin_lock" },
	{ 0x72df2f2a, "up_read" },
	{ 0x118f01ea, "putname" },
	{ 0x50eedeb8, "printk" },
	{ 0xe2d5255a, "strcmp" },
	{ 0x215f9a25, "current_task" },
	{ 0x7c60d66e, "getname" },
	{ 0xd0f0d945, "down_read" },
	{ 0xb4390f9a, "mcount" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=";


MODULE_INFO(srcversion, "73249F644EC9E3F1F081FF3");
