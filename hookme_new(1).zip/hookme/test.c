#include <stdio.h>
#include "mylib.h"

int main (int argc, char** argv)
{
  FILE* inf = NULL;
  inf = fopen(argv[1], argv[2]);
  if (inf == NULL)
  {
    printf("Open %s with %s NOT ALLOWED\n", argv[1], argv[2]);
    return(0);
  }
  printf("%s opened with %s SUCCESS\n", argv[1], argv[2]);
  fclose(inf);
  return(0);
}
