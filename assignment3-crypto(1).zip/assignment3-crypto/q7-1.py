from Crypto.Cipher import AES
from Crypto import Random
import base64

key = 'This is my key12'

cipher = AES.new(key,AES.MODE_ECB)

inputText = 'This is my plain text message...'
inputText1 = 'This is my plain text message1..'
inputText2 = 'This is my plain text message12.'
inputText3 = 'This is my plain text message...'

inputTextFinal = inputText + inputText1 + inputText2 + inputText3

print inputTextFinal

cipherText = base64.b64encode(cipher.encrypt(inputTextFinal))

print cipherText

modifiedCT = '2lRrCgfibboqt5/q2OGWIrH4FiO3wSwVUxNWaGsn/AXaVGsKB+ktuiq3n+rY4ZYim2t8qwLKKlWlPXnFTZSCYNpUawoH4m26Kref6tjhliL1Te+02T5Q6VVUduuKFg+52lRrCgfibboqt5/q2OGWIrH4FiO3wSwVUxNWaGsn/AU='

plainTextD = cipher.decrypt(base64.b64decode(modifiedCT))

print plainTextD
