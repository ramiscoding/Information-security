from Crypto.Cipher import AES
from Crypto import Random
import base64

key = 'This is my key12'

cipher = AES.new(key,AES.MODE_ECB)

inputText = 'This is my plain text message...'
inputText1 = 'This is my plain text message1..'
inputText2 = 'This is my plain text message12.'
inputText3 = 'This is my plain text message...'

inputTextFinal = inputText + inputText1 + inputText2 + inputText3

print inputTextFinal

cipherText = base64.b64encode(cipher.encrypt(inputTextFinal))

print cipherText

key2 = 'This is my key15'
cipher2 = AES.new(key2,AES.MODE_ECB)

plainTextD = cipher2.decrypt(base64.b64decode(cipherText))

print plainTextD
