from Crypto.Cipher import AES
import base64
import os
from Crypto import Random

BLOCK_SIZE = 16

PADDING = '{'

key = 'thisismykey12345'

def pad(input):
  paddedOutput = input + (BLOCK_SIZE - len(input) % BLOCK_SIZE) * PADDING
  return paddedOutput

def EncryptFunction(k, input):
  paddedInput = pad(input)
  iv = Random.new().read(16)
  cipher = AES.new(k,AES.MODE_CBC,iv)
  return base64.b64encode(iv + cipher.encrypt(paddedInput))

def DecryptFunction(k, ct):
  cipherTextD = base64.b64decode(ct)
  iv = cipherTextD[:16]
  cipher = AES.new(k,AES.MODE_CBC,iv)
  return cipher.decrypt(cipherTextD[16:]).rstrip(PADDING)


inputText = 'Secret message A'
inputText1 = 'Secret message B'
inputText2 = 'Secret message C'
inputText3 = 'Secret message A'

inputTextFinal = inputText + inputText1 + inputText2 + inputText3

inputEve = 'Give Eve $100...'


cipherText = EncryptFunction(key, inputTextFinal)
print 'Cipher Text:', cipherText
print len(cipherText)

newCT = cipherText[:-64]

cipherEve = EncryptFunction(key, inputEve)

replayCT = newCT + cipherEve
print len(cipherEve)

plainText = DecryptFunction(key, replayCT)
print 'Plain Text:', plainText
